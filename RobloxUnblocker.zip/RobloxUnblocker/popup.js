const UI_DATA = {
    en: { start: "START", stop: "STOP", guide: "Guide", off: "OFFLINE", on: "READY", s1: "1. Open <b>Settings</b> > <b>Privacy</b>", s2: "2. Find <b>Blocked Users</b>", s3: "3. Click <b>Show</b>", s4: "4. Target URL: <b>.../BlockedUsers</b>" },
    ru: { start: "ЗАПУСТИТЬ", stop: "ОСТАНОВИТЬ", guide: "Инструкция", off: "НЕ ТА СТРАНИЦА", on: "ГОТОВО", s1: "1. Зайди в <b>Settings</b> > <b>Privacy</b>", s2: "2. Найди <b>Blocked Users</b>", s3: "3. Нажми <b>Show</b>", s4: "4. Нужен URL: <b>.../BlockedUsers</b>" }
};

const _ = (s) => document.querySelector(s);
let currentLang = 'en';
let isPageValid = false;

function applyLang(l) {
    currentLang = l;
    document.querySelectorAll('.lang-opt').forEach(opt => {
        opt.classList.toggle('active', opt.dataset.value === l);
    });

    const d = UI_DATA[l];
    _('#start').innerText = d.start;
    _('#stop').innerText = d.stop;
    _('#mTitle').innerText = d.guide;
    _('#s1').innerHTML = d.s1;
    _('#s2').innerHTML = d.s2;
    _('#s3').innerHTML = d.s3;
    _('#s4').innerHTML = d.s4;
    _('#closeBtn').innerText = l === 'ru' ? 'Понятно' : 'Done';
    
    _('#dot').classList.toggle('on', isPageValid);
    _('#stat').innerText = isPageValid ? d.on : d.off;
    _('#start').style.opacity = isPageValid ? '1' : '0.4';
    _('#start').style.pointerEvents = isPageValid ? 'all' : 'none';
}

async function check() {
    if (!chrome.tabs) return;
    try {
        let [t] = await chrome.tabs.query({active: true, currentWindow: true});
        isPageValid = !!(t?.url?.toLowerCase().includes('roblox.com') && t?.url?.toLowerCase().includes('blockedusers'));
        applyLang(currentLang);
    } catch (e) {}
}

document.querySelectorAll('.lang-opt').forEach(opt => {
    opt.onclick = () => {
        let v = opt.dataset.value;
        applyLang(v);
        if (chrome.storage && chrome.storage.local) {
            chrome.storage.local.set({saved_lang: v});
        }
    };
});

_('#infoBtn').onclick = () => _('#modal').classList.add('open');
_('#closeBtn').onclick = () => _('#modal').classList.remove('open');
_('#devLink').onclick = () => chrome.tabs.create({url: 'https://github.com/alkin1yt'});

_('#start').onclick = async () => {
    let [t] = await chrome.tabs.query({active: true, currentWindow: true});
    _('#start').style.display = 'none';
    _('#stop').style.display = 'flex';
    chrome.scripting.executeScript({target: {tabId: t.id}, function: script});
};

_('#stop').onclick = async () => {
    let [t] = await chrome.tabs.query({active: true, currentWindow: true});
    chrome.scripting.executeScript({target: {tabId: t.id}, function: () => { window._ab = true; }});
    _('#stop').style.display = 'none';
    _('#start').style.display = 'flex';
};

function snowflakes() {
    for(let i=0; i<30; i++){
        let f = document.createElement('div');
        f.className = 'flake';
        f.innerHTML = '❄';
        f.style.left = Math.random()*100+'%';
        f.style.opacity = Math.random()*0.4+0.1;
        f.style.fontSize = Math.random()*10+5+'px';
        f.style.animationDuration = Math.random()*5+3+'s';
        f.style.animationDelay = Math.random()*5+'s';
        document.body.appendChild(f);
    }
}

async function script() {
    window._ab = false;
    const get = () => Array.from(document.querySelectorAll('button')).filter(x => {
        const t = (x.innerText || x.textContent).trim().toLowerCase();
        return (t === 'unblock' || t === 'разблокировать') && !x.closest('.modal-dialog');
    });

    while(!window._ab) {
        let targets = get();
        if(targets.length === 0) {
            window.scrollBy(0, 500);
            await new Promise(r => setTimeout(r, 800));
            if(get().length === 0) break;
            continue;
        }

        for(const b of targets) {
            if(window._ab) break;
            b.click();
            await new Promise(r => setTimeout(r, 450));
            const cf = Array.from(document.querySelectorAll('.modal-dialog button, .modal-content button')).find(x => {
                const t = (x.innerText || x.textContent).toLowerCase();
                return t.includes('unblock') || t.includes('разблокировать') || t.includes('confirm');
            });
            if(cf) cf.click();
            await new Promise(r => setTimeout(r, 1100));
        }
    }
}

snowflakes();

if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    chrome.storage.local.get(['saved_lang'], function(r) {
        currentLang = r.saved_lang || (navigator.language.startsWith('ru') ? 'ru' : 'en');
        check();
    });
} else {
    currentLang = navigator.language.startsWith('ru') ? 'ru' : 'en';
    check();
}

setInterval(check, 1500);